October  2007        
Dr. Dobb's Journal         
   
File: VCRYPT.TXT 
Title: Visual Cryptography and Bit-Plane Complexity Segmentation
Daniel Stoleru  
Keywords: OCT07    SECURITY     CRYPTOGRAPHY       GRAPHICS   
Description: Published and unpublished source code accompanying the article by Daniel Stoleru in 
which he examines Bit-Plane Complexity Segmentation which lets you embed 
large amounts of data in images.

File: VISTA.ZIP  
Title: Inside the Windows Vista Disk Encryption Algorithm  
Author: Mohamed Abo El-Fotouh and Klaus Diepold  
Keywords: OCT07 SECURITY     WINDOWS    VISTA   
Description: Unpublished source code accompanying the article by Mohamed Abo El-Fotouh and 
Klaus Diepold in which they examine how Windows Vista protects the 
confidentiality of data on hard disks using Bitlocker Drive Encryption, 
which is based on the  AES-CBC + Elephant diffuser algorithm. Requires 
UNZIP/PKUNZIP to extract 
 
File: MEMAWARE.TXT  
Title: Memory-Aware Components
Author: Kirk J. Krauss  
Keywords: OCT07   WINDOWS    COMPONENTS    MEMORY
Description: Published and unpublished source code accompanying the article by  Kirk J. Krauss 
in which he points out that in an ideal world, your programs gracefully 
handle out-of-memory conditions and keep running. But in the real 
world....
 
File: LOGCPP.ZIP  
Title: Logging In C++
Author: Petru Marginean
Keywords: OCT07   C++  
Description: Unpublished source code accompanying the article by Petru Marginean, in which 
he presents a C++ logging framework that is typesafe, thread-safe, and 
portable. Requires UNZIP/PKUNZIP to extract 
 

